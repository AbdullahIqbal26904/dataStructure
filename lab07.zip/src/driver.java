public class driver {
    public static void main(String[] args) {
    // Create a new BST object
    BinaryTree<Integer> bst = new BinaryTree<>();

    // Insert some elements
    bst.insert(50);
    bst.insert(30);
    bst.insert(70);
    bst.insert(20);
    bst.insert(40);
    bst.insert(60);
    bst.insert(80);

    // Print inorder traversal (LNR)
    System.out.println("Inorder Traversal (LNR):");
    bst.LNR(bst.root);
    System.out.println();

    // Print postorder traversal (LRN)
    System.out.println("Postorder Traversal (LRN):");
    bst.LRN(bst.root);
    System.out.println();

    // Find elements
    Node<Integer> node30 = bst.find(30);
    Node<Integer> node90 = bst.find(90);

    System.out.println("Found 30: " + (node30 != null));
    System.out.println("Found 90: " + (node90 != null));

    // Find minimum and maximum
    Node<Integer> minNode = bst.Minimum();
    Node<Integer> maxNode = bst.Maximum();

    System.out.println("Minimum Node: " + minNode.data);
    System.out.println("Maximum Node: " + maxNode.data);


}
}
