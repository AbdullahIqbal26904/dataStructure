public class Node<T> {
    Node left;
    Node right;
    T data;

    public Node(T data) {
        this.data = data;
    }
}
