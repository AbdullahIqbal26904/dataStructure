public class BinaryTree<T extends Comparable<T>> {
    Node<T> root;
    public void insert(T data){
        if (root==null){
            root=new Node<T>(data);
            return;
        }
        Node<T> n = new Node<T>(data);
        Node<T> curr = root;
        Node<T> prev=null;
        while (curr!=null){
            prev=curr;
            if(data.compareTo(curr.data)<0){
                curr=curr.left;
            }else {
                curr=curr.right;
            }
        }
        if(data.compareTo(prev.data)<0){
            prev.left=n;
        } else {
            prev.right=n;
        }
    }
    public Node<T> find(T keys){
        if(root==null){
            return null;
        }
        Node<T> prev=null;
        Node<T> temp = root;
        while (temp!=null){
            prev=temp;
            if(keys.compareTo(temp.data)==0) return temp;
            if(keys.compareTo(temp.data)<0){
                temp=temp.left;
            }else {
                temp=temp.right;
            }
        }
        return null;
    }
    public  void LNR(Node<T> root)
    {
        if (root == null)
            return;
        LNR(root.left);
        System.out.print(root.data + "\n");
        LNR(root.right);
    }
    public  void LRN(Node<T> root)
    {
        if (root == null)
            return;
        LNR(root.left);
        LNR(root.right);
        System.out.print(root.data + "\n");
    }
    public Node<T> Maximum(){
        Node<T> temp = root;
        while (temp.right!=null){
            temp=temp.right;
        }
        return temp;
    }
    public Node<T> Minimum(){
        Node<T> temp = root;
        while (temp.left!=null){
            temp=temp.left;
        }
        return temp;
    }
}
